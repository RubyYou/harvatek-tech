<?php
include_once '../config/config.main.php';
session_start();
session_destroy();
?>