<?php include_once 'copyright.c.php';?>
<div id="copyright_wrap">
    <?php echo FULLCOPYRIGHT;?>
</div>