<?php include_once 'sidebar.c.php';?>
<!DOCTYPE>
<html>
<head>
<title><?php echo BGM_TITLE;?></title>
<?php require_once WEB_PATH.'include/head.inc.php';?>
</head>
<body id="sidebar">
<div id="wrapper">
    <div id="header"></div>
    <div id="main">
	<div class="sidebar_wrap">
	    <?php echo $fSideBar;?>
	</div>
    </div>
    <div id="footer"></div>
</div>
</body>
</html>