<?php
$server = "mysql16.000webhost.com";
$database = "a5099492_tech";
$user = "a5099492_tech";
$password = "harvatek-tech";
?>