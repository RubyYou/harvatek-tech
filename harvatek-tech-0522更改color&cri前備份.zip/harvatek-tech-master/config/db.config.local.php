<?php
$server='127.0.0.1';
$user='nick';
$password='nick';
$database='harvatek-tech';
?>