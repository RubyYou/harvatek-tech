
	<!-- Footer
    ================================================== -->

	<section id="footer">
		<div class="titleBar">
			<div class="col-xs-4 barblue"> </div>
			<div class="col-xs-4 barsky"> </div>
			<div class="col-xs-4 bargreen"> </div>
		</div>
		<div class="container">
	      	<div class="col-md-4">
	      		<h3>Harvatek Technology</h3>
		  		<p>Small intro about the comopany-<br/>
					Harvateck is a company provides<br/>
					advanced technology in LED sector.<br/><br/>
					Copyright © 2014. All Right Reserved. 
		  		</p>
	      	
	      	</div>
	      	<div class="col-md-5">
	      		<div class="row">
	      		<ul class="col-md-6 mainlink">
	      			<li><a href="company-profile.php">Company Profile</a></li>
	      			<li><a href="global-locations.php">Global Locations</a></li>
	      			<li><a href="applications.php">Applications</a></li>
	      			<li><a href="news.php">News</a></li>
	      			<li><a href="local-representatives.php">Local Representatives</a></li>
	      			<li><a href="contact.php">Contact US</a></li>
	      		</ul>
	      		<ul class="col-md-6">
	      			<li class="mainlink">Products</li>
	      			<li><a href="">Display</a></li>
	      			<li><a href="">SMD LED</a></li>
	      			<li><a href="">Through Hole LED</a></li>
	      			<li><a href="">Infrared Emitter/Sensor/Coupler</a></li>
	      			<li><a href="">UV LED</a></li>
	      		</ul>
	      		</div>
	      	</div>
	      	<div class="col-md-3">
	      		<p><b>3350 Scott Blvd #41-01, Santa Clara, CA, 95054</b><br/>
					TEL:+1 408 884 3871<br/>
					Fax: +1 408 844 9618<br/>
					Email: sales@harvatek-tech.com<br/>
					
	      		</p>
	      	</div>
        </div>
	</section>