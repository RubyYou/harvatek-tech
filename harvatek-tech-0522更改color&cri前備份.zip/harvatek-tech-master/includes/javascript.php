	<!-- JavaScript
    ================================================== -->
	<script src="scripts/jquery-1.11.0.js" type="text/javascript" ></script>
	<script src="scripts/bootstrap/bootstrap.js" type="text/javascript" ></script>
	<script src="scripts/bootstrapValidator.min.js" type="text/javascript" ></script>
	<script src="scripts/jquery.accordion.source.js" type="text/javascript" ></script>
	<script src="scripts/script.js" type="text/javascript" ></script>
	<script src="http://localhost:35729/livereload.js"></script>