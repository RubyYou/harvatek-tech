	<!-- Side menu // product categories
    ================================================== -->
	<div class="col-md-3">
		<h4 class="categoryTitle">PRODUCT CATEGORIES</h4>
		<?php echo $categoriesMenu;?>
		
		<!--
		<ul class="accordion">
			<li>
				<a class="toggle"><img src="images/inolux_icon.png" alt="inolux-product-icon"/>DISPLAY</a>
					<ul>
						<li><a href="#display-throughhole" class="toggle">Through Hole Display</a>
							<ul>
								<li><a href="#display-throughhole-numeric" class="toggle">Numeric</a>
									<ul>
										<li><a href="#display-numeric-single">Single Digit</a></li>
										<li><a href="#display-numeric-dual">Dual Digit</a></li>
										<li><a href="#display-numeric-triple">Triple Digit</a></li>
										<li><a href="#display-numeric-four">four digit</a></li>
									</ul>
								</li>
								<li><a href="#display-throughhole-dotMetri">Dot Metrix</a></li>
							</ul>
						</li>
						<li><a href="#display-smddisplay" class="toggle">SMD Display</a>
							<ul>
								<li><a href="#display-smddisplay-single">Single Digit</a></li>
								<li><a href="#display-smddisplay-dual">Dual Digit</a></li>
								<li><a href="#display-smddisplay-triple">Triple Digit</a></li>
								<li><a href="#display-smddisplay-four">Four digit</a></li>
							</ul>
						</li>
					</ul>
			</li>
			<li><a class="toggle">
				<img src="images/harvatek_icon.png" alt="harvatek-product-icon"/>SMD LED</a>
				<ul>
					<li><a href="#smdled-surfaceMount">Surface Mount</a></li>
					<li><a href="#smdled-backLight" class="toggle">Back lighting</a>
						<ul>
							<li><a href="#smdled-backLight-0.06w">0.06W</a></li>
							<li><a href="#smdled-backLight-0.1w">0.1W</a></li>
							<li><a href="#smdled-backLight-0.4w">0.4W</a></li>
							<li><a href="#smdled-backLight-1.0w">1.0W</a></li>
						</ul>
					</li>
					<li><a href="#smdled-generalLight" class="toggle">General lighting</a>
						<ul>
							<li><a href="#smdled-generalLight-0.06w">0.06W</a></li>
							<li><a href="#smdled-generalLight-0.1w">0.1W</a></li>
							<li><a href="#smdled-generalLight-0.2w">0.2W</a></li>
							<li><a href="#smdled-generalLight-0.5w">0.5W</a></li>
							<li><a href="#smdled-generalLight-1w">1W</a></li>
						</ul>
					</li>
					<li><a href="#smdled-lm80" class="toggle">LM-80</a>
						<ul>
							<li><a href="#smdled-lm80-0.1w">0.1W</a></li>
							<li><a href="#smdled-lm80-0.5w">0.5W</a></li>
						</ul>
					</li>
					</li>
				</ul>
			</li>
			<li><a href="#throughholeled" class="toggle">
				<img src="images/inolux_icon.png" alt="inolux-product-icon"/>THROUGH HOLE LED</a>
				<ul>
					<li><a href="#throughholeled-round">Round Lamp</a></li>
					<li><a href="#throughholeled-oval">Oval Lamp</a></li>
					<li><a href="#throughholeled-piranha">Piranha</a></li>
					<li><a href="#throughholeled-leadFrame">Lead Frame Axial</a></li>
					<li><a href="#throughholeled-lampHousing">Lamp with Housing</a></li>
				</ul>
			</li>
			<li><a href="#infrared" class="toggle">
				<img src="images/ctm_icon.png" alt="CTM-product-icon"/>Infrared Emitter/Sensor/Coupler</a>
				<ul>
					<li><a href="#infrared-emitter">Emitter</a></li>
					<li><a href="#infrared-sensor">Sensor</a></li>
					<li><a href="#infrared-coupler">Photo Coupler</a></li>
				</ul>
			</li>
			<li><a href="#uvled">
				<img src="images/inolux_icon.png" alt="inolux-product-icon"/>UV LED</a>
			</li>
		</ul>
		-->
	</div>