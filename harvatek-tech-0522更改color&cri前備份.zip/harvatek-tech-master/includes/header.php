<!doctype html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="Author" content="Harvatek-tech.com" />
  <meta name="Keywords" content=""/>
  <meta name="Description" content="" />
  <meta http-equiv="Content-Script-Type" content="text/javascript" />

  <!--mobile setup // this is todo

  <link rel="apple-touch-icon" href="images/iphone-57.png"/>
  <link rel="icon" href="images/ulacicon.ico" type="image/ico" />
	--> 
  <link rel="stylesheet" type="text/css" media="screen" href="scripts/bootstrap/bootstrap.css" />
  <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" >
  <link rel="stylesheet" type="text/css" media="screen" href="scripts/css/style.css" />

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <title>
    Harvatek-tech | Lighting your future
  </title>
  <!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js">
	</script>
  <![endif]-->

</head>